describe('SAS Website', () => {
     it('loads search page', () => {
       // body > div.page-header.js-page-header > div > div > div.page-header__center > div > form > label > input
     cy.visit('https://www.sas.am');
     });
     it('check if the searchbar exists', () => {
        
        cy.get('.search__label').children('input').should('exist');
       })
    it('searches for the text input with a certain place holder', () => {
         cy.get('.search__label').children('input').invoke('attr', 'placeholder').should('contain', 'Ցանկանում եմ գնել...');
       });
       it('searches for `juice`', () => {
         cy.get('input[name="q"]').type('Ցանկանում','{force: true}');   
        // cy.get('.search__label').children('input').type('j','{force: true}');
        // cy.get('.search__form').children('input').type('Ցանկանում','{force: true}');
      });
    
})
